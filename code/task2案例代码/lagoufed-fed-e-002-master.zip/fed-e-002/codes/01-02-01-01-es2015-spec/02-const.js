// const name = 'zce'
// 恒量声明过后不允许重新赋值
// name = 'jack'

// 恒量要求声明同时赋值
// const name
// name = 'zce'

// 恒量只是要求内层指向不允许被修改
// const obj = {}
// 对于数据成员的修改是没有问题的
// obj.name = 'zce'

// obj = {}
