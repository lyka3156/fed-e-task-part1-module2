/**
 * 类型推断
 *
 * @flow
 */

function square (n) {
  return n * n
}

// square('100')

square(100)
