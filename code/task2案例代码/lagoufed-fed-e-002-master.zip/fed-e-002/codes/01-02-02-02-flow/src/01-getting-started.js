// @flow

function sum (a: number, b: number) {
  return a + b
}

sum(100, 100)

// sum('100', '100')

// sum('100', 100)
