# 大前端高薪训练营 002 期

> 大前端高薪训练营 002 期相关资料

点我 点我 点我👉[大前端高薪训练营入营资料](prepare) 

我们会随着学习计划，同步更新此仓库中对应的相关资料。

## Table of Contents

- 录播部分
  + [录播部分代码](codes)
  + [录播部分讲义](handouts)
  + [录播学习笔记](notes)
- 直播部分
  + [直播内容归档](live)
- 日常部分
  + [面试题归档](interviews)
  + [随堂测试归档](tests)
  + [模块作业归档](tasks)
  + [作业提交要求](tasks/requirements.md)

## 意见或建议

如果你有什么好的意见和建议，可以随时通过 [Issues](https://gitee.com/lagoufed/fed-e-002/issues) 提出。

还是那句话 Issues 不是贴吧，请勿灌水 😄😄😄。

## 版权说明

&copy; 2020 [拉勾教育](https://kaiwu.lagou.com), 保留一切权利.
